/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(tabs)` | `/(tabs)/` | `/(tabs)/history` | `/(tabs)/list-order` | `/(tabs)/profile` | `/_sitemap` | `/auth` | `/auth/login` | `/cart/cart` | `/context` | `/context/AuthContext` | `/context/CartContext` | `/history` | `/list-order` | `/menu/detail` | `/my-order/detail` | `/profile`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
