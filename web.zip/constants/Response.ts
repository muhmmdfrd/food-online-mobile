export const Response = {
  successCode: "0000",
  unauthorizedCode: "4400",
};
