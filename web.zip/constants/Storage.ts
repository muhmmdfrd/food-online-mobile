export const Storage = {
  token: "TOKEN",
  currentUser: "CURRENT_USER",
  code: "SESSION_CODE",
  cart: "CART",
};
