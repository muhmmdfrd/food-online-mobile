export type AuthRequest = {
  username: string;
  password: string;
};
