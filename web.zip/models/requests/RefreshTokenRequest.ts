export type RefreshTokenRequest = {
  userId: number;
  code: string;
};
