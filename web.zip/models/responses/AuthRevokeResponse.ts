export type AuthRevokeResponse = {
  token: string;
  code: string;
};
