type OrderResponse = {
  id: number;
  statusName: string;
  code: string;
  date: string;
  status: number;
  menus: string[];
  total: number;
};
