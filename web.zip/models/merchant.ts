export type Merchant = {
  id: number;
  name: string;
};
